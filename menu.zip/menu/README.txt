files without extention, in this folder is every menu of the restaurant(restaurant name is same to the file name)
style of menu file: a big array contains tuples, each tuple is one menu item, first element in tuple is title, second is breif description(maybe empty)
[('Everything Is Everything Crumpets', 'Lox. Fried egg salad. Tzatziki cream cheese. Pickles'),('title',''),('title','description')]

files with extention review are caption-url pairs for the restaurant with same name to the file.

menu.list contains all the restaurants' name we would use to check.

review folder can be ignored.


